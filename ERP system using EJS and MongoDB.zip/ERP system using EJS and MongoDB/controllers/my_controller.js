const userModel = require('../models/db.js')
const bcrypt = require('bcrypt')
const appointmentModel = require('../models/appointments.js')
const { use } = require('../routes/web.js')
const { render } = require('ejs')
const mongoose = require('mongoose');
const defaultId = 'default';

class MyController{
    // Login Page
    static loginController = (req,res) =>{
        res.render('login.ejs')
    }

    // Get method G2Page
    static g2Controller = async (req,res) =>{
        if(req.session.UserType!='Driver'){
            res.redirect('/dashboard')
        }
        console.log("Username"+req.session.username);
        const user = await userModel.findOne({Username:req.session.username})
        const lnum = await bcrypt.compare("default",user.license_number)
        let license;
        const appointments = await appointmentModel.find()
        const timeslots = [];
        appointments.forEach((appointment)=>{
            const obj = {
                time: ((appointment.date).toString()).concat("  ",appointment.timeslot),
                isAvailable : appointment.isTimeSlotAvailable 
            }
            timeslots.push(obj)
        })
        console.log(timeslots)
        if (!lnum){
            license='Encrypted and stored in db'
        }
        else{
            license="default"
        }
        if(user)
            res.render('G2.ejs',{
                    firstname: user.firstname,
                    lastname: user.lastname,
                    license_number: license,
                    Age: user.Age,
                    Username: user.Username,
                    Password: user.Password, 
                    UserType: user.UserType,
                    timeslot: timeslots,
                    car_details: {
                    make: user.car_details.make,
                    model: user.car_details.model,
                    year: user.car_details.year,
                    platno: user.car_details.platno
                }
            });
            else{
                console.log('User does not exists')
                res.redirect('/login');
            }
    }

    static getAppointmentController = (req,res)=>{
        if((req.session.UserType).toString()!='Admin')
            res.redirect('/login');
        if(req.session.UserType=='Admin')
            res.render('appointment.ejs',{msgs:''})
        else
            res.redirect('/login')
    }

    static getLogoutController = (req,res)=>{
        req.session.UserType = '';
        req.session.username = '';
        req.session.comments='';
        req.session.status='';
        res.redirect('/login');
    }

    static getdash2 = (req,res)=>{
        res.render('dashboard2.ejs')
    }

    static postAppointmentController = async (req,res)=>{
        const time_posted = req.body
        const existing_model = await appointmentModel.findOne({date:time_posted.dates,timeslot:time_posted.timeslot});
        console.log(existing_model)
        if(!existing_model){
            appointmentModel.create(
                {   id:Math.floor(Date.now() / 1000).toString(),
                    timeslot: time_posted.timeslot,
                    date: time_posted.dates,
                    isTimeSlotAvailable: true
                }
            );
            res.render('appointment.ejs',{msgs:'appointment created successfully!'})
        }
        else{
            res.render('appointment.ejs',{msgs:'appointment is already exists. Please choose another date and time. '})
        }
    }

    // Get method Dashboards
    static dashController = (req,res) =>{
        res.render('Dashboard.ejs',{msg:req.session.username,UserType:req.session.UserType,status:req.session.status,comments:req.session.comments,type:''});
    }

    // Get Signup Page
    static getSignUpController = (req,res)=>{
        res.render('signup.ejs')
    }

    // Post Signup Page
    static postSignUpController = async (req,res)=>{
        const userData = req.body;
        const username = userData.susername
        const existinguser = await userModel.findOne({Username:userData.susername})
        req.session.UserType = userData.susertype;
        console.log(existinguser);
        if(existinguser){
            console.log('User already exists');
            res.redirect('/login');
        }
        else{
        const hashpassword = await bcrypt.hash(userData.suserpassword,10)
        const appointments = await appointmentModel.find()
        const timeslots = [];
        appointments.forEach((appointment)=>{
            const obj = {
                time: ((appointment.date).toString()).concat("  ",appointment.timeslot),
                isAvailable : appointment.isTimeSlotAvailable 
            }
            timeslots.push(obj)
        })
        console.log(timeslots)
        console.log(req.session.UserType)
        userModel.create({
            firstname: 'default',
            lastname: 'default',
            license_number:'default',
            Age: 0,
            Username: username,
            Password: hashpassword, 
            UserType: userData.usertype,
            appointmentID: defaultId,
            type: 'default',
            comment: '',
            status:'default',
            car_details: {
            make: 'default',
            model: 'default',
            year: 0,
            platno: 'default',
            },
        },(error,user)=>{
            if(error){
                console.log(error)
            }else{
                if(userData.usertype!='Driver'){
                    res.redirect('/dashboard2')
                }
                res.render('G2.ejs',{
                    firstname: 'default',
                    lastname: 'default',
                    license_number:'default',
                    Age: 0,
                    Username: username,
                    Password: hashpassword, 
                    UserType: userData.susertype,
                    car_details: {
                    make: 'default',
                    model: 'default',
                    year: 0,
                    platno: 'default',
                    },
                    timeslot: timeslots,
                })
            }})
        }
    }

    // Post Method on G2 Page
    // Update user values
    static g2SubmitController = async (req,res)=>{
        const userData = req.body;
        // Hashing license number
        const hashed_license = await bcrypt.hash(userData.lnum,10);
        const dateAndTime = (userData.timeslot).split(" ");
        const tss = dateAndTime[2].concat(" ",dateAndTime[3])
        console.log(tss)
        const appointments = await appointmentModel.find()
        const timeslots = [];
        appointments.forEach((appointment)=>{
            const obj = {
                time: ((appointment.date).toString()).concat("  ",appointment.timeslot),
                isAvailable : appointment.isTimeSlotAvailable 
            }
            timeslots.push(obj)
        })
        const apnt = appointmentModel.findOneAndUpdate(
            {
                timeslot:tss,
                date:dateAndTime[0],
                isTimeSlotAvailable:true
            },{
                timeslot:tss,
                date:dateAndTime[0],
                isTimeSlotAvailable:false
            },(error)=>{
            console.log(error)
        })
        userModel.findOneAndUpdate({Username:req.session.username},{
            firstname: userData.fname,
            lastname: userData.lname,
            Username:req.session.username,
            license_number: hashed_license,
            appointmentID: "booked",
            type:'G2',
            Age: userData.age,
            car_details: {
            make: userData.make,
            model: userData.model,
            year: userData.year,
            platno: userData.platno, 
        }
    },(error,user)=>{
            if(error){
                console.log(error)
            }
            else{
                res.render('G_.ejs',{
                    firstname: userData.fname,
                    lastname: userData.lname,
                    username: req.session.Username,
                    license_number: userData.lnum,
                    Age: userData.age,
                    timeslot:timeslots,
                    car_details: {
                    make: userData.make,
                    model: userData.model,
                    year: userData.year,
                    platno: userData.platno,
                    }
                })
            }
        })
    }

    //Driver View
    static postDriver = async (req,res)=>{
        if((req.session.UserType).toString()!='Examiner')
            res.redirect('/login');
        const user = await userModel.findOne({Username:req.body.euname});
        if(user){
            res.render('driver.ejs',{username:user.Username, 
                type:user.type,
                status:user.status,
                comments:user.comments,
                make: user.car_details.make,
                model: user.car_details.model,
                year: user.car_details.year,
                platno: user.car_details.platno,
                });
        }
    }

    //Method to update comments and remarks to driver
    static giveRemarks = async (req,res)=>{
        const driver = req.body;
        console.log('Remarks');
        console.log(driver)
        const user =  userModel.findOneAndUpdate({Username:driver.uname},{comment:driver.comments,status:driver.decision},(error,user)=>{
        if(user){
           console.log(user);
            res.render('msg.ejs');
        }
         if(error){
             console.log(error)
         }
        });
    }

    //Filter controller for examiner page
    static filterController = async(req,res)=>{
        const filterOption = req.body.filter;
        let queryOption,users;
        console.log(filterOption);
        switch(filterOption){
            case 'G':  queryOption='G';
                    break;
            case 'G2': queryOption='G2';
                    break;
            default:  queryOption=null;
                    break;
        }
        if(queryOption){
             users = await userModel.find({type:queryOption});
        }
        else{
             users = await userModel.find({type:{$ne:'default'}});
        }
        const datausers = [];
        const dataapnt = [];
        if(users){
            users.forEach((user)=>{
                const obj = {};
                obj.username = user.Username;
                obj.type = user.type;
                datausers.push(obj);
            })
        }
        const appointment =  await appointmentModel.find({isTimeSlotAvailable:false});
        appointment.forEach((apnt)=>{
            let obj = {};
            console.log(apnt)
            obj.time=apnt.timeslot;
            obj.date=apnt.date;
            dataapnt.push(obj);
        });
        res.render('examiner.ejs',{users:datausers,appointments:dataapnt});
    }

    // Post Method on G_ Page
    // Update an existing use
    static gdashSubmitController = async (req,res)=>{
        const userData = req.body;
        const dateAndTime = (userData.timeslot).split(" ");
        const tss = dateAndTime[2].concat(" ",dateAndTime[3])
        console.log(tss)
        appointmentModel.findOneAndUpdate(
            {
                timeslot:tss,
                date:dateAndTime[0],
                isTimeSlotAvailable:true
            },{
                isTimeSlotAvailable:false
            },(error)=>{
                if(error)
            console.log(error)
        });
        userModel.findOneAndUpdate({Username:req.session.username},{
                    firstname: userData.fname,
                    lastname: userData.lname,
                    Age: userData.age,
                    appointmentID: 'booked',
                    type:'G',
                    car_details: {
                    make: userData.make,
                    model: userData.model,
                    year: userData.year,
                    platno: userData.platno,
                }
            },(error)=>{
                if(error)
                    console.log(error);
            }); 
        res.render('S.ejs')
    }

    //Examiner
    static getExaminerController = async (req,res) =>{
        const users = await userModel.find({appointmentID : 'booked'});
        const datausers = [];
        const dataapnt = [];
        if(users){
            users.forEach((user)=>{
                const obj = {};
                obj.username = user.Username;
                obj.type = user.type;
                datausers.push(obj);
            })
        }
        const appointment =  await appointmentModel.find({isTimeSlotAvailable:false});
        appointment.forEach((apnt)=>{
            let obj = {};
            console.log(apnt)
            obj.time=apnt.timeslot;
            obj.date=apnt.date;
            dataapnt.push(obj);
        });
        console.log(dataapnt)
        console.log(datausers)
        res.render('examiner.ejs',{users:datausers,appointments:dataapnt});
    }

    // submit login form
    static successLogin = async (req,res) =>{
        const userData = req.body
        req.session.username=userData.username;
        console.log(req.session.username);
        const userInDB = await userModel.findOne({Username:userData.username})
        if(userInDB){
            req.session.UserType=userInDB.UserType
            console.log(userInDB)
            req.session.comments = userInDB.comment
            req.session.status =userInDB.status
            const match = await bcrypt.compare(userData.userpwd,userInDB.Password)
            if(match)
                res.render('dashboard.ejs',{UserType: userInDB.UserType,msg:userInDB.Username,comments:userInDB.comment,status:userInDB.status,type:userInDB.type})
            else{
                console.log('incorrect password')
                res.redirect('/login')
            }
        }
        else{
            console.log("User Not Found")
            res.redirect('/login')
        }
    }

    // Get on G_ Page
    static gdashController = async (req,res)=>{
        if(req.session.UserType!='Driver'){
            res.redirect('/dashboard')
        }
        const userData = req.body;
        const user = await userModel.findOne({Username:req.session.username})
        const appointments = await appointmentModel.find()
        const timeslots = [];
        appointments.forEach((appointment)=>{
            const obj = {
                time: ((appointment.date).toString()).concat("  ",appointment.timeslot),
                isAvailable : appointment.isTimeSlotAvailable 
            }
            timeslots.push(obj)
        })
        if(user)
            res.render('G_.ejs',{
                    firstname: user.firstname,
                    lastname: user.lastname,
                    license_number: user.license_number,
                    Age: user.Age,
                    Username: user.Username,
                    Password: user.Password,
                    timeslot: timeslots, 
                    UserType: user.UserType,
                    car_details: {
                    make: user.car_details.make,
                    model: user.car_details.model,
                    year: user.car_details.year,
                    platno: user.car_details.platno,
                }
            });
            else{
                console.log('User does not exists')
                res.redirect('/login');
            }
    }
}

module.exports = MyController;