const express = require('express');

const router = express.Router();

// routers for various routes and methods
const AuthenticationController = require('../controllers/my_controller.js');
const appointmentModel = require('../models/appointments.js');

router.get('/login',AuthenticationController.loginController);

router.get('/G2',AuthenticationController.g2Controller,);

router.get('/dashboard',AuthenticationController.dashController);

router.get('/signup',AuthenticationController.getSignUpController);

router.get('/appointment',AuthenticationController.getAppointmentController);

router.get('/logout',AuthenticationController.getLogoutController);

router.get('/dashboard2',AuthenticationController.getdash2);

router.get('/',(req,res)=>{
    res.redirect('/login');
})

router.get('/G_',AuthenticationController.gdashController);

router.get('/examiner',AuthenticationController.getExaminerController);

router.post('/G',AuthenticationController.g2SubmitController);

router.post('/driver',AuthenticationController.postDriver);

router.post('/msg',AuthenticationController.giveRemarks);

router.post('/examiner',AuthenticationController.filterController);

router.post('/G2',AuthenticationController.postSignUpController);

router.post('/dashboard',AuthenticationController.successLogin);

router.post('/S',AuthenticationController.gdashSubmitController);

router.post('/appointment',AuthenticationController.postAppointmentController)

module.exports =  router;