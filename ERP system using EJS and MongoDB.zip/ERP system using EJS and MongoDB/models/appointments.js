const mongoose = require('mongoose')

// connect to database
mongoose.connect("mongodb+srv://topa:topachuptha@clusterNumber.vqlt77d.mongodb.net/drivetest?retryWrites=true&w=majority ",{useNewUrlParser:true,useUnifiedTopology:true},(error)=>
{
    if(error)
        console.log(error);
    else
        console.log("Connection succeded");
})

// Creating userschema
const appointmentsSchema = mongoose.Schema({    
    id:{type:String,unique:true,required:true},
    timeslot: String,
    date: String,
    isTimeSlotAvailable: Boolean,
})

//Exporting model
const appointmentModel = mongoose.model("appointments",appointmentsSchema);
module.exports = appointmentModel;