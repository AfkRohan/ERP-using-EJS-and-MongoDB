const mongoose = require('mongoose')

// connect to database
mongoose.connect("mongodb+srv://topa:topachuptha@clusterNumber.vqlt77d.mongodb.net/drivetest?retryWrites=true&w=majority ",{useNewUrlParser:true,useUnifiedTopology:true},(error)=>
{
    if(error)
        console.log(error);
    else
        console.log("Connection succeded");
})

// Creating userschema
const userSchema = mongoose.Schema({    
    firstname: String,
    lastname: String,
    license_number: String,
    Age: Number,
    Username:{type:String,required:true,unique:true},
    Password: String, 
    UserType: String,
    car_details: {
    make: String,
    model: String,
    year: Number,
    platno: String,
    },
    appointmentID:String,
    type:String,
    comment: String,
    status:String,
})

//Exporting model
const userModel = mongoose.model("user",userSchema);
module.exports = userModel;