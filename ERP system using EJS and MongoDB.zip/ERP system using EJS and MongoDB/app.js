const express = require('express')

const hostname = '127.0.0.1'
const port = 3000

const app = express('app')

const userModel = require('./models/db.js')

const session = require('express-session')

const bodyParser = require('body-parser')

const path = require('path');

const router =  require('./routes/web.js')
const { error } = require('console')

app.set('view-engine','ejs')

app.use(express.static(__dirname+'/public'))

app.use(session({
  secret:'my_secret',
  resave: false,
  saveUninitialized: false,
  cookie: { path: '/', _expires: 24*60*60*1000, httpOnly: true }
}))


app.use(bodyParser.urlencoded({extended:true}))

app.use('',router)

app.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`)
})