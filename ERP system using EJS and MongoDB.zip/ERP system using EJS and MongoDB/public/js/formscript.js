const userModel = require('../models/db.js')

document.getElementById("sub1").addEventListener("click",()=>{
    document.getElementsByClassName("toggle").style.visinility="visible";
    const license_number = document.getElementById("rellnum").value;    
})